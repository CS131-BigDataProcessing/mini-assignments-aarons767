"""
crime_test: For Crime data validation and statistical calculations.

Version: 1.0.0
"""

__version__ = "1.0.0"
__author__ = "Aaron D'Souza"
__email__ = "aarond.dsouza@sjsu.edu"
