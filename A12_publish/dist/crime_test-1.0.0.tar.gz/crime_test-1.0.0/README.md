
# Features

- Validate columns from csv file like 'Vict Age' and 'Vict Sex'.
- Find statistics like mean and median.

# Installation

```bash
pip install crime_test

